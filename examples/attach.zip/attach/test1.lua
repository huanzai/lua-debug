
local function _do()
    local a = 1
    local b = 2

    local c = a+b
    return c + 10
end

return _do
