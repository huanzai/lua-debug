* Run `lua test.lua`.
* Open VSCode, and press `F5`.
